<?php
	$flag="Tenesys19{wh0a_y0u\'ve_g0t_th3_m4g1c_numb3r}"
?>