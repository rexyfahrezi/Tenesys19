<?php
include("flag.php");

if (isset($_GET['passwd'])) {
        if (hash("md5", $_GET['passwd']) == '0e514198428367523082236389979035'){
			echo "<script>alert('$flag');window.location='index.php'</script>";
        } else {
			echo "<script>alert('Wrong!');window.location='index.php'</script>";
	}
} 
?>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Login Page</title>
<form class="box" action="index.php" method="get">
  <h1>M a g i c</h1>
  <input type="password" name="passwd" placeholder="Password">
  <input type="submit" value="LOGIN" />
</form>