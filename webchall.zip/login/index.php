<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Page</title>
</head>
<body>
    <form action="">
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
    <?php
        $secret = "p455w0rd";
        if(isset($_GET["password"])){
            $password = $_GET["password"];
            if(strcmp($password, $secret) == 0){
                echo "Tenesys19{5trcmp_vu1n}";
            }else{
                echo "Wrong Password!";
            }
        }
    ?>
</body>
</html>
