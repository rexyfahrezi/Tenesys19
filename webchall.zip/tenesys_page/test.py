Split = '1234567812345678'
n = 8
[Split[i:i+n] for i in range(0, len(Split), n)]
print (Split)