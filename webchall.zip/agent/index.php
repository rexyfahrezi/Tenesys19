<!DOCTYPE html>
<html>
   <head>
      <title>Mata-mata</title>
   </head>
</html>
<?php
$agent = $_SERVER['HTTP_USER_AGENT'];
echo "Halo ". $agent;
echo "\n<b>Hanya TenesysBrowser yang bisa mendapatkan akses masuk ke web ini!</b><br><br>";

if ($agent != "TenesysBrowser") {
    echo "Hekel ya?";
} else {
    echo "Welcome to TENESYS!\nTenesys19{c4nt_tru5t_u5er_ag3nt}";
}
?>