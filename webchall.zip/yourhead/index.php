<?php
$agent = $_SERVER['HTTP_USER_AGENT'];
header('Flag: Tenesys19{g0t_th3_head3r}');
?>
<html>
<head><title>Kepala</title>
</head><body><center>
<img src="/webchall/yourhead/paramex.jpg" style="height:260px; width:250px" alt="paramex"><p>
All the flag it's in your head</center></body>
</html>