<!DOCTYPE html>
<html>
   <head>
      <title>Kue</title>
   </head>
   <body>
      <center><img src="https://media.giphy.com/media/xT0xeMA62E1XIlup68/giphy.gif" 
		alt="CookieMonster" width="400px" height="300px"></center>
   </body>
</html>

<?php
setcookie("user", base64_encode("user"));
$kue = $_COOKIE['user'];
$flag = "Tenesys19{i_4te_4ll_th3_c00k1e}";

if ($kue == base64_encode("admin")) {
    echo $flag;
}
?>